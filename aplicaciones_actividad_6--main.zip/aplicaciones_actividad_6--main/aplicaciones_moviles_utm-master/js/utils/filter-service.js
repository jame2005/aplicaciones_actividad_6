/**
 * Aplica filtros de texto y tipo sobre el array de rutas
 */
export function aplicarFiltrosCombinados(rutas, texto, tipo) {
    return rutas.filter(ruta => {
        const coincideTexto = !texto || 
            ruta.destino.toLowerCase().includes(texto.toLowerCase()) ||
            ruta.bus.toLowerCase().includes(texto.toLowerCase());
        
        const coincideTipo = !tipo || ruta.tipo === tipo;
        
        return coincideTexto && coincideTipo;
    });
}

/**
 * Ordena las rutas por horario de forma ascendente
 */
export function ordenarPorHorario(rutas) {
    return [...rutas].sort((a, b) => a.horario.localeCompare(b.horario));
}