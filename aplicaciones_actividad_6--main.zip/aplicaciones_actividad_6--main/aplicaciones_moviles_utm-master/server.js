const express = require('express');
const cors = require('cors');
const app = express();
const PORT = 3000;

app.use(cors());
app.use(express.json());

// Datos de ejemplo (Mock Data)
let rutas = [
    { id: 1, destino: "Facultad de Ingeniería", bus: "Bus 01", horario: "07:00", tipo: "Normal", estado: "Disponible" },
    { id: 2, destino: "Campus Central", bus: "Bus 05", horario: "08:30", tipo: "Expreso", estado: "Disponible" },
    { id: 3, destino: "Biblioteca General", bus: "Bus 03", horario: "12:00", tipo: "Normal", estado: "Mantenimiento" }
];

/**
 * GET /
 * Ruta raíz para verificar el estado del servidor
 */
app.get('/', (req, res) => {
    res.send('<h1>Servidor API Funcionando</h1><p>Consulta los datos en: <a href="/api/rutas">/api/rutas</a></p>');
});

/**
 * @endpoint GET /api/rutas
 * @description Retorna la lista completa de rutas universitarias.
 * @returns {Array<Object>} 200 - Lista de rutas.
 * @returns {Object} 500 - Error interno del servidor.
 */
app.get('/api/rutas', (req, res) => {
    try {
        console.log('Petición recibida en GET /api/rutas');
        res.status(200).json(rutas);
    } catch (error) {
        console.error('Error en el servidor:', error);
        res.status(500).json({ mensaje: "Error al obtener las rutas" });
    }
});

/**
 * @endpoint POST /api/rutas
 * @description Crea un nuevo registro de ruta con ID autogenerado.
 * @body {string} destino, bus, horario, tipo, estado.
 * @returns {Object} 201 - El objeto creado.
 * @returns {Object} 400 - Error por falta de campos obligatorios.
 * @returns {Object} 500 - Error al procesar la creación.
 */
app.post('/api/rutas', (req, res) => {
    try {
        const { destino, bus, horario, tipo, estado } = req.body;
        if (!destino || !bus || !horario || !tipo || !estado) {
            return res.status(400).json({ mensaje: "Faltan datos obligatorios" });
        }
        const nuevaRuta = {
            id: rutas.length > 0 ? Math.max(...rutas.map(r => r.id)) + 1 : 1,
            destino,
            bus,
            horario,
            tipo,
            estado
        };
        rutas.push(nuevaRuta);
        res.status(201).json(nuevaRuta);
    } catch (error) {
        res.status(500).json({ mensaje: "Error al crear la ruta" });
    }
});

/**
 * @endpoint PUT /api/rutas/:id
 * @description Actualiza los datos de una ruta existente.
 * @param {number} id - ID de la ruta en la URL.
 * @body {Object} Datos a actualizar (destino, bus, horario, tipo, estado).
 * @returns {Object} 200 - El objeto actualizado.
 * @returns {Object} 404 - Ruta no encontrada.
 * @returns {Object} 500 - Error al actualizar.
 */
app.put('/api/rutas/:id', (req, res) => {
    try {
        const id = parseInt(req.params.id);
        const index = rutas.findIndex(r => r.id === id);
        if (index === -1) {
            return res.status(404).json({ mensaje: "Ruta no encontrada" });
        }
        const { destino, bus, horario, tipo, estado } = req.body;
        rutas[index] = { ...rutas[index], destino, bus, horario, tipo, estado };
        res.json(rutas[index]);
    } catch (error) {
        res.status(500).json({ mensaje: "Error al actualizar la ruta" });
    }
});

/**
 * @endpoint DELETE /api/rutas/:id
 * @description Elimina físicamente un registro del arreglo.
 * @param {number} id - ID de la ruta en la URL.
 * @returns {Object} 200 - Mensaje de confirmación.
 * @returns {Object} 404 - Ruta no encontrada.
 */
app.delete('/api/rutas/:id', (req, res) => {
    const id = parseInt(req.params.id);
    const existe = rutas.some(r => r.id === id);
    if (!existe) {
        return res.status(404).json({ mensaje: "Ruta no encontrada" });
    }
    rutas = rutas.filter(r => r.id !== id);
    res.json({ mensaje: "Ruta eliminada correctamente" });
});

app.listen(PORT, () => {
    console.log(`Servidor API corriendo en http://localhost:${PORT}`);
    console.log(`Endpoints disponibles: GET, POST, PUT, DELETE en http://localhost:${PORT}/api/rutas`);
});
